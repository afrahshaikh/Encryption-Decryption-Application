package com.example.encrptdecyrpt;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Base64;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.security.MessageDigest;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public class MainActivity extends AppCompatActivity {
EditText text,pass;
TextView output;
Button enc,dec;
String outputtext;
String AES="AES";
String checkpass="abc123";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        text=findViewById(R.id.editText);
        pass=findViewById(R.id.editText2);
        output=findViewById(R.id.textView);
        enc=findViewById(R.id.button);
        dec=findViewById(R.id.button2);

        enc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                    try {
                        if(pass.getText().toString().equals("abc123"))
                        {
                        outputtext = encrypt(text.getText().toString(), pass.getText().toString());
                        output.setText(outputtext);}
                        else
                            Toast.makeText(MainActivity.this, "Incorrect Password", Toast.LENGTH_SHORT).show();
                    } catch (Exception e) {

                        e.printStackTrace();
                    }

            }
        });
        dec.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                    try {
                        if(pass.getText().toString().equals("abc123")) {
                            outputtext = decrypt(outputtext, pass.getText().toString());
                            output.setText(outputtext);}
                        else
                            Toast.makeText(MainActivity.this, "Incorrect Password", Toast.LENGTH_SHORT).show();

                    } catch (Exception e) {
                        Toast.makeText(MainActivity.this, "INcorrect password", Toast.LENGTH_SHORT).show();
                        e.printStackTrace();
                    }
                    output.setText(outputtext);

            }
        });
    }

    private String decrypt(String outputtext, String password) throws Exception {

            SecretKeySpec key = generateKey(password);
            Cipher c = Cipher.getInstance(AES);
            c.init(Cipher.DECRYPT_MODE, key);
            byte[] decodedvalue = Base64.decode(outputtext, Base64.DEFAULT);
            byte[] decvalue = c.doFinal(decodedvalue);
            String decryptedvalue = new String(decvalue);
            return decryptedvalue;
        }


    private String encrypt(String Data,String password) throws Exception{
        SecretKeySpec key= generateKey(password);
        Cipher c=Cipher.getInstance(AES);
        c.init(Cipher.ENCRYPT_MODE,key);
        byte[] encval=c.doFinal(Data.getBytes());
        String encryptedvalue= Base64.encodeToString(encval,Base64.DEFAULT);
        return encryptedvalue;
    }
    private SecretKeySpec generateKey(String password) throws Exception{
        final MessageDigest digest=MessageDigest.getInstance("SHA-256");
        byte[] bytes=password.getBytes("UTF-8");
        digest.update(bytes,0,bytes.length);
        byte[] key=digest.digest();
        SecretKeySpec secretKeySpec=new SecretKeySpec(key,"AES");
        return secretKeySpec;
    }
}
